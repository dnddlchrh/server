package kr.hs.sdhs.portfollo_chanwoong;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private long lastBackPressed = 0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void onBackPressed(){
//        super.onBackPressed();

        if(System.currentTimeMillis() - lastBackPressed > 2000){
            Toast.makeText(this,"함 더 누름 종료",Toast.LENGTH_SHORT).show();
            lastBackPressed = System.currentTimeMillis();
        }else{
            finish();
            System.exit(0);
            android.os.Process.killProcess(android.os.Process.myPid());
        }
    }

    public void onButoonClick(View view){
        switch (view.getId()){
            case R.id.button_gocalc:
                Intent calcintent = new Intent(MainActivity.this, CalcActivity.class);
                startActivity(calcintent);
                break;
            case R.id.button_go_browser:
                Intent browserintent = new Intent(MainActivity.this, BrowserActivity.class);
                startActivity(browserintent);
                break;
            case R.id.button_insta:
                Intent instaintent = new Intent(MainActivity.this, BabyinstaActivity.class);
                startActivity(instaintent);
                break;
        }
    }
}
